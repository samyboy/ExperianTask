package com.experian.assement.extractor;

public class FileExtractorApplication {

	public static void main(String[] args) {
		
		TestCaseFileExtractor testCaseFileExtractor = new TestCaseFileExtractor();
        testCaseFileExtractor.start();
    }
	}

