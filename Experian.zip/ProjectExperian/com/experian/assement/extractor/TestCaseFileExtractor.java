package com.experian.assement.extractor;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;

public class TestCaseFileExtractor {
	public final static Integer DEFAULT_NO_OF_TEST_CASES_TO_EXTRACT = 10;

    public String extractTestCasesFromFileRandomly(String inputFileName, Integer numberOfTestCasesToExtract) {
        Integer extensionIndex = inputFileName.lastIndexOf(".");
        Integer subStringIndex = extensionIndex >= 0 ? extensionIndex : inputFileName.length();
        String outputFilePath = inputFileName.substring(0, subStringIndex) + "_res" + inputFileName.substring(subStringIndex);
        numberOfTestCasesToExtract = Optional.ofNullable(numberOfTestCasesToExtract).orElse(DEFAULT_NO_OF_TEST_CASES_TO_EXTRACT);
        try {
            List<String> allTestCasesFromInputFileWithHeader = Files.readAllLines(Path.of(inputFileName));
            if(allTestCasesFromInputFileWithHeader != null && !allTestCasesFromInputFileWithHeader.isEmpty()) {
                // if file have records less than number of test cases to extract
                if(numberOfTestCasesToExtract >= allTestCasesFromInputFileWithHeader.size()) {
                    return writeToOutputFile(outputFilePath, allTestCasesFromInputFileWithHeader);
                }
                // shuffle list to have random behaviour of extraction
                String header = allTestCasesFromInputFileWithHeader.remove(0);
                Collections.shuffle(allTestCasesFromInputFileWithHeader);
                List<String> outputLines = allTestCasesFromInputFileWithHeader.subList(0, numberOfTestCasesToExtract);
                outputLines.add(0, header);
                return writeToOutputFile(outputFilePath, outputLines);
            }
        } catch (IOException ioException) {
            System.err.println("Error occurred while reading input file. Please verify provided file and check its existence in FS. Error : " + ioException.getMessage());
        }
        return outputFilePath;
    }

    private String writeToOutputFile(String outputFilePath, List<String> extractedOutputFileContent) {
        try {
            Files.write(Path.of(outputFilePath), extractedOutputFileContent, StandardOpenOption.CREATE_NEW, StandardOpenOption.APPEND);
        } catch (IOException ioException) {
            System.err.println("Error occurred while reading input file. Please verify if you have access to write. Error : " + ioException.getMessage());
            return null;
        }
        return outputFilePath;
    }

    public void start() {
        @SuppressWarnings("resource")
		Scanner inputSrc = new Scanner(System.in);
        System.out.println("Please type input file-path + file-name (mandatory) : ");
        String inputFilePath = inputSrc.nextLine();
        System.out.println("Please type number of test-cases to extract from input file (optional and default to 10): ");
        Integer numberOfTestCasesToExtract = inputSrc.nextInt();
        String outputFilePath = this.extractTestCasesFromFileRandomly(inputFilePath, numberOfTestCasesToExtract);
        if(outputFilePath != null) {
            System.out.println("Output file-path : "+outputFilePath);
        }
    }
}
